app.controller('topController', ['$scope',
 function ($scope) {
    $scope.titol="Listame";
 }]);