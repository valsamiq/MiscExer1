app.controller('cosController', ['$scope',
 function ($scope) {
 $scope.titol = "EL COS";
 }]);