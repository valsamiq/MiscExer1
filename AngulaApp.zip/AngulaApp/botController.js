app.controller('botController', ['$scope',
 function ($scope) {
 $scope.titol = "EL COS";
 }]);